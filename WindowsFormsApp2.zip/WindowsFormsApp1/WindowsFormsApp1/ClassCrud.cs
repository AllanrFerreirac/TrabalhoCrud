﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace CRUDIZINHOBasico
{
    class ClassCrud
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public string celular { get; set; }
        public DateTime data_nas { get; set; }
        public string email { get; set; }
        public List<ClassCrud> listaclasscrud()
        {
            List<ClassCrud> li = new List<ClassCrud>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM crud";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ClassCrud u = new ClassCrud();
                u.Id = (int)dr["Id"];
                u.nome = dr["nome"].ToString();
                u.celular = dr["celular"].ToString();
                u.data_nas = Convert.ToDateTime(dr["data_nas"]);
                u.email = dr["email"].ToString();
                li.Add(u);
            }
            return li;
        }
        public void Inserir(string nome, string celular, DateTime data_nas, string email)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO crud(nome,celular,data_nas,email) VALUES ('" + nome + "','" + celular + "',Convert(DateTime,'" + data_nas + "',103),'" + email + "')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Localiza(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM crud WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                nome = dr["nome"].ToString();
                celular = dr["celular"].ToString();
                data_nas = Convert.ToDateTime(dr["data_nas"]);
                email = dr["email"].ToString();
            }
        }

        public void Editar(int id, string nome, string celular, DateTime data_nas, string email)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "UPDATE crud SET nome='" + nome + "',celular='" + celular + "',data_nas=Convert(DateTime,'" + data_nas + "',103),email='" + email + "' WHERE Id = '" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void Exclui(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "DELETE FROM crud WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }
    }
}
