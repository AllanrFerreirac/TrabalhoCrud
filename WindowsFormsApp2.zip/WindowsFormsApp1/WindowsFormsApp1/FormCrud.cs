﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;

namespace CRUDIZINHOBasico
{
    public partial class FormCrud : Form
    {
        public FormCrud()
        {
            InitializeComponent();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void CRUDIZINHOBasico_Load(object sender, EventArgs e)
        {
            ClassCrud usu = new ClassCrud();
            List<ClassCrud> crud = usu.listaclasscrud();
            dgvCrud.DataSource = crud;
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                ClassCrud crud = new ClassCrud();
                crud.Inserir(txtNome.Text, txtCelular.Text, dtpData_nas.Value, txtEmail.Text);
                MessageBox.Show("Usuário cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<ClassCrud> usu = crud.listaclasscrud();
                dgvCrud.DataSource = usu;
                txtNome.Text = "";
                txtCelular.Text = "";
                this.dtpData_nas.Value = DateTime.Now.Date;
                txtEmail.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                ClassCrud usuario = new ClassCrud();
                usuario.Localiza(id);
                txtNome.Text = usuario.nome;
                txtCelular.Text = usuario.celular;
                dtpData_nas.Value = Convert.ToDateTime(usuario.data_nas);
                txtEmail.Text = usuario.email;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                ClassCrud crud = new ClassCrud();
                crud.Editar(id, txtNome.Text, txtCelular.Text, dtpData_nas.Value, txtEmail.Text);
                MessageBox.Show("Usuário atualizado com sucesso!", "Edição", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<ClassCrud> usu = crud.listaclasscrud();
                dgvCrud.DataSource = usu;
                txtId.Text = "";
                txtNome.Text = "";
                txtCelular.Text = "";
                this.dtpData_nas.Value = DateTime.Now.Date;
                txtEmail.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                ClassCrud crud = new ClassCrud();
                crud.Exclui(id);
                MessageBox.Show("Usuário excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<ClassCrud> usu = crud.listaclasscrud();
                dgvCrud.DataSource = usu;
                txtId.Text = "";
                txtNome.Text = "";
                txtCelular.Text = "";
                this.dtpData_nas.Value = DateTime.Now.Date;
                txtEmail.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtNome.Text = "";
            txtCelular.Text = "";
            this.dtpData_nas.Value = DateTime.Now.Date;
            txtEmail.Text = "";
        }

        private void dgvCrud_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvCrud.Rows[e.RowIndex];
                txtId.Text = row.Cells[0].Value.ToString().Trim();
                txtNome.Text = row.Cells[1].Value.ToString().Trim();
                txtCelular.Text = row.Cells[2].Value.ToString().Trim();
                dtpData_nas.Value = Convert.ToDateTime(row.Cells[3].Value);
                txtEmail.Text = row.Cells[4].Value.ToString().Trim();
            }
        }
    }
}
